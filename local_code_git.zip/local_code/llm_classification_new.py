import pandas as pd
import google.generativeai as genai
import time
import json
import os

# === Configuration ===
OUTDIR = "Output_Headers"
API_KEY = "AIzaSyA49yemyX2JJhOvDXWX-Mk2XfXxyXL-8ME"  # Replace with your real API key
INPUT_FILE = r"C:\Projects\Financial-Population\Output_Headers\structured_headers_2025-07-31.xlsx"
SAVE_EVERY = 5
OUTPUT_CSV = "classified_sections.csv"
OUTPUT_XLSX = "classified_sections.xlsx"
OUTPUT_JSON = "classified_sections.json"

# === Setup Gemini ===
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("models/gemini-1.5-flash")

# === Load previous progress if available ===
if os.path.exists(OUTPUT_XLSX):
    df = pd.read_excel(OUTPUT_XLSX)
    print("🔄 Loaded existing progress from classified_sections.xlsx")
else:
    df = pd.read_excel(INPUT_FILE) if INPUT_FILE.endswith(".xlsx") else pd.read_csv(INPUT_FILE)
    df["text_for_classification"] = df["Header"].fillna('') + " " + df["Subheader"].fillna('')
    if "classification" not in df.columns:
        df["classification"] = ""

# === Clean classifier text ===
def clean_text(text):
    return str(text).strip().replace('\n', ' ').replace('\r', ' ').strip()

# === Classification logic ===
def classify_with_retry(text, retries=3):
    prompt = f"""
You are an AI assistant that classifies document sections into one of the following:
1. Financial
2. Generic
3. Appendix
4. Notes

Classify this section: "{text}"

Only return the category name (Financial, Generic, Appendix, or Notes).
""".strip()

    valid_classes = {"Financial", "Generic", "Appendix", "Notes"}
    delay = 2

    for attempt in range(retries):
        try:
            response = model.generate_content(prompt)
            answer = response.text.strip().split('\n')[0].strip()

            if answer in valid_classes:
                return answer
            else:
                print(f"⚠️ Invalid response from model: '{answer}' → Marked as Unknown")
                return "Unknown"

        except Exception as e:
            print(f"❌ Attempt {attempt+1} failed for '{text[:50]}...': {e}")
            if "quota" in str(e).lower() or "token" in str(e).lower():
                print("⏳ Rate limit hit. Sleeping for 60 seconds...")
                time.sleep(60)
            else:
                time.sleep(delay)
                delay *= 2

    return "Unknown"

# === Find first unclassified index to resume from ===
unclassified_mask = (df["classification"].astype(str).str.strip().isin(["", "Unknown"]))
start_index = unclassified_mask.idxmax() if unclassified_mask.any() else len(df)

print(f"▶️ Resuming from row {start_index} of {len(df)}")

# === Process remaining rows ===
for i in range(start_index, len(df)):
    text = clean_text(df.loc[i, "text_for_classification"])
    print(f"\n🧠 Classifying {i+1}/{len(df)}: {text[:60]}...")

    result = classify_with_retry(text)
    df.loc[i, "classification"] = result
    print(f"✅ Result: {result}")

    time.sleep(1.1)  # Respect rate limits

    # Save progress every SAVE_EVERY rows
    if (i + 1) % SAVE_EVERY == 0:
        df.to_excel(OUTPUT_XLSX, index=False)
        df.to_csv(OUTPUT_CSV, index=False)
        df.to_json(OUTPUT_JSON, orient="records", indent=4)
        print(f"💾 Auto-saved progress at row {i+1}")

# === Final Save ===
df.drop(columns=["text_for_classification"], inplace=True, errors='ignore')
df.to_csv(OUTPUT_CSV, index=False)
df.to_excel(OUTPUT_XLSX, index=False)
df.to_json(OUTPUT_JSON, orient="records", indent=4)

print("\n✅ All sections classified and saved!")
