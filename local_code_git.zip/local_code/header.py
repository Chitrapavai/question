import fitz  # PyMuPDF
import os
from datetime import datetime
from PIL import Image
import pytesseract
import io
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from dotenv import load_dotenv

load_dotenv()

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

header_font_size = float(os.getenv("HEADER_FONT_SIZE"))
subheader_font_size = float(os.getenv("SUBHEADER_FONT_SIZE"))

def clean_text(text):
    # Remove illegal characters for Excel (non-printable or control characters)
    return ''.join(char for char in text if char.isprintable())

def extract_headers_with_structure(pdf_path, output_dir=os.getenv("HEADER_DIR")):
    doc = fitz.open(pdf_path)
    structured_data = []
    current_header = None
    headers = {}

    for page_num in range(len(doc)):
        page = doc[page_num]
        blocks = page.get_text("dict")["blocks"]

        if not blocks:
            # OCR fallback
            pix = page.get_pixmap(dpi=300)
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            ocr_text = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)

            for i, text in enumerate(ocr_text["text"]):
                text = clean_text(text.strip())
                if not text or len(text) < 3:
                    continue
                try:
                    conf = int(ocr_text["conf"][i])
                    height = int(ocr_text["height"][i])
                except ValueError:
                    continue

                if conf > 60:
                    y0 = ocr_text["top"][i]
                    y1 = y0 + height
                    font_size = height
                    source = "OCR"

                    if font_size >= header_font_size:
                        current_header = text
                        headers.setdefault(current_header, {"start": page_num + 1, "end": page_num + 1})
                        structured_data.append({
                            "Header": current_header,
                            "Subheader": "",
                            "Page": page_num + 1,
                            "Y_Start": y0,
                            "Y_End": y1,
                            "Font_Size": font_size,
                            "Source": source
                        })
                    elif font_size >= subheader_font_size and current_header:
                        structured_data.append({
                            "Header": current_header,
                            "Subheader": text,
                            "Page": page_num + 1,
                            "Y_Start": y0,
                            "Y_End": y1,
                            "Font_Size": font_size,
                            "Source": source
                        })
                        headers[current_header]["end"] = page_num + 1
        else:
            # Digital text
            for block in blocks:
                if "lines" not in block:
                    continue
                for line in block["lines"]:
                    for span in line["spans"]:
                        text = clean_text(span["text"].strip())
                        font_size = span["size"]
                        bbox = span["bbox"]
                        y0, y1 = bbox[1], bbox[3]
                        source = "Digital"

                        if not text or len(text) < 3:
                            continue

                        if font_size >= header_font_size:
                            current_header = text
                            headers.setdefault(current_header, {"start": page_num + 1, "end": page_num + 1})
                            structured_data.append({
                                "Header": current_header,
                                "Subheader": "",
                                "Page": page_num + 1,
                                "Y_Start": round(y0, 2),
                                "Y_End": round(y1, 2),
                                "Font_Size": round(font_size, 2),
                                "Source": source
                            })
                        elif font_size >= subheader_font_size and current_header:
                            structured_data.append({
                                "Header": current_header,
                                "Subheader": text,
                                "Page": page_num + 1,
                                "Y_Start": round(y0, 2),
                                "Y_End": round(y1, 2),
                                "Font_Size": round(font_size, 2),
                                "Source": source
                            })
                            headers[current_header]["end"] = page_num + 1

    if not structured_data:
        print("⚠️ No header/subheader structure found.")
        return

    df = pd.DataFrame(structured_data)

    # Add header start and end page columns
    df["Header_Start_Page"] = df["Header"].apply(lambda h: headers[h]["start"] if h in headers else "")
    df["Header_End_Page"] = df["Header"].apply(lambda h: headers[h]["end"] if h in headers else "")

    # Prepare filenames
    os.makedirs(output_dir, exist_ok=True)
    date_str = datetime.today().strftime('%Y-%m-%d')
    base_name = f"structured_headers_{date_str}"
    xlsx_path = os.path.join(output_dir, base_name + ".xlsx")
    csv_path = os.path.join(output_dir, base_name + ".csv")
    json_path = os.path.join(output_dir, base_name + ".json")

    # Save in multiple formats
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    df.to_json(json_path, orient="records", indent=4, force_ascii=False)
    df.to_excel(xlsx_path, index=False)

    # Format Excel: merge cells by header
    wb = load_workbook(xlsx_path)
    ws = wb.active
    current_row = 2
    while current_row <= ws.max_row:
        header_val = ws[f"A{current_row}"].value
        merge_start = current_row
        while current_row <= ws.max_row and ws[f"A{current_row}"].value == header_val:
            current_row += 1
        merge_end = current_row - 1
        if merge_start != merge_end:
            ws.merge_cells(start_row=merge_start, start_column=1, end_row=merge_end, end_column=1)
            ws[f"A{merge_start}"].alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)

    wb.save(xlsx_path)

    print(f"✅ Saved to:\n📘 Excel: {xlsx_path}\n📄 CSV: {csv_path}\n📦 JSON: {json_path}")

# Entry point
extract_headers_with_structure(os.getenv("PDF_PATH"))
