import os
import json
import pickle
import faiss
import numpy as np
import pandas as pd
from tqdm import tqdm
from google import genai
from google.genai import types  #"AIzaSyDg4-xN4ItnZ0d6gyu3rQWpgt8Pt0MogNw,   AIzaSyDqAYD6aPGt9FNGI55rBFQDqPdcjwTNnCg"

GEMINI_API_KEY = "AIzaSyB3aQ9m_TI-Cch6u1ecW7oOlFPYOCqPeow" 
JSON_FILE = r"C:\Projects\Financial-Population\embedding_volex_2024_faiss_test\test.json"   # input json file
QUESTIONS_FILE = r"C:\Projects\Financial-Population\test_llm - Sheet1.csv"      # csv with columns: Metric, Question
OUTPUT_FILE = "test_llm_results_docs.csv"

EMBED_DIM = 768
# FAISS_INDEX_FILE = "faiss_index.bin"
# FAISS_META_FILE = "faiss_meta.pkl"


client = genai.Client(api_key=GEMINI_API_KEY)
GEMINI_MODEL = "gemini-1.5-flash"


# def load_stream_tables(json_file):
#     with open(json_file, "r", encoding="utf-8") as f:
#         data = json.load(f)

#     stream_tables = data.get("stream_tables", [])
#     docs = []
#     for tbl_idx, tbl_str in enumerate(stream_tables):
#         try:
#             rows = json.loads(tbl_str)  # tables are stored as JSON strings
#             for row in rows:
#                 row_text = " | ".join(
#                     str(v) for v in row.values()
#                     if v is not None and str(v).strip().lower() != "nan"
#                 )
#                 if row_text.strip():
#                     docs.append(row_text)
#         except Exception as e:
#             print(f"Failed to parse table {tbl_idx}: {e}")

#     return "\n".join(docs)


def load_docs(json_file):
    with open(json_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    
    docs = data.get("docs", [])
    
    if not docs:
        raise ValueError("No valid docs found in the JSON!")

 
    return "\n".join(docs)

# def answer_question(metric, statement_type, question, context):
#     prompt = f"""
# You are a financial assistant expert.

# Here is the extracted financial table content:
# {context}

# Statement Type: {statement_type}
# Metric: {metric}
# Question: {question}

# Provide a clear, precise answer based strictly on the context above.
# If the answer cannot be found, respond with "Not available in provided data".
# """

#     response = client.models.generate_content(
#         model=GEMINI_MODEL,
#         contents=prompt
#     )
#     return response.text.strip()


def answer_question(metric, question, context):
    prompt = f"""
You are a financial assistant expert.

Here is the extracted financial table content:
{context}


Metric: {metric}
Question: {question}

Provide a clear, precise answer based strictly on the context above.
If the answer cannot be found, respond with "Not available in provided data".
"""

    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt
    )
    return response.text.strip()


def main():
    print("=== Running Gemini Financial QA ===")

    # Load stream_table content
    context = load_docs(JSON_FILE)

    # Load questions
    df = pd.read_csv(QUESTIONS_FILE)

    results = []
    for _, row in tqdm(df.iterrows(), total=len(df)):
        metric = str(row["metrics"])
        question = str(row["question"])
       
        answer = answer_question(metric, question, context)

        results.append({
            "Metric": metric,
            "Question": question,
            "Answer": answer
        })

    # Save answers
    results_df = pd.DataFrame(results)
    results_df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")
    print(f" Results saved to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
