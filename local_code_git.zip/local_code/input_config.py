#####TFL ###################
pdf_path = r"C:\Projects\Financial-Population\source-pdf\tfl-2024.pdf"
query_excel_path = r"C:\Projects\Financial-Population\question\Provision_Derivative_Questions.xlsx"
output_csv_path = "tfl_Provision_Derivative_Retreival.csv"

base_name = Path(pdf_path).stem
os.makedirs("embedding_tfl-2024_new1", exist_ok=True)
EMBEDDINGS_CACHE = f"embedding_tfl-2024_new1/{base_name}_embedded_text.json"
EXCEL_FILE_STREAM = f"embedding_tfl-2024_new1/{base_name}_stream.xlsx"
EXCEL_FILE_LATTICE = f"embedding_tfl-2024_new1/{base_name}_lattice.xlsx"
JSON_FILE_STREAM = f"embedding_tfl-2024_new1/{base_name}_stream.json"
JSON_FILE_LATTICE = f"embedding_tfl-2024_new1/{base_name}_lattice.json"
NOTES_EXCEL_PATH = f"embedding_tfl-2024_new1/{base_name}_AllNotes.xlsx"
NOTE_EMBEDDINGS_CACHE = f"embedding_tfl-2024_new1/{base_name}_note_embeddings.json"
HEADER_LOOKUP = {
    "Balance Sheet": [
        "Notes to the Financial Statements",
        "Group Balance Sheet"
    ],
    "Consolidated Statement of Financial Position": [
        "Notes to the Financial Statements",
        "Group Balance Sheet"
    ],
    "Consolidated Balance Sheet": [
        "Notes to the Financial Statements",
        "Group Balance Sheet"
    ],
    "Group and Parent Company Balance Sheet": [
        "Notes to the Financial Statements",
        "Group Balance Sheet",
        "Corporation Balance Sheet"
    ],
    "Consolidated and Company Balance sheet": [
        "Notes to the Financial Statements",
        "Group Balance Sheet"
    ],
    "Company Balance Sheet": [
        "Notes to the Financial Statements",
        "Corporation Balance Sheet"
    ],
    "Consolidated Balance Sheet": [
        "Notes to the Financial Statements",
        "Group Balance Sheet"
    ]


}

###### Bristol #############

pdf_path = r"C:/Projects/Financial-Population/source-pdf/Bristol_2024.pdf"
query_excel_path = r"C:/Projects/Financial-Population/question/bristol_questions_2024.xlsx"
source_sheet_name = "direct"
output_csv_path = "bristol_lookup_direct-op.csv"

base_name = Path(pdf_path).stem
os.makedirs("embedding_Bristol_2024_new", exist_ok=True)
EMBEDDINGS_CACHE = f"embedding_Bristol_2024_new/{base_name}_embedded_text.json"
EXCEL_FILE_STREAM = f"embedding_Bristol_2024_new/{base_name}_stream.xlsx"
EXCEL_FILE_LATTICE = f"embedding_Bristol_2024_new/{base_name}_lattice.xlsx"
JSON_FILE_STREAM = f"embedding_Bristol_2024_new/{base_name}_stream.json"
JSON_FILE_LATTICE = f"embedding_Bristol_2024_new/{base_name}_lattice.json"
NOTES_EXCEL_PATH = f"embedding_Bristol_2024_new/{base_name}_AllNotes.xlsx"
NOTE_EMBEDDINGS_CACHE = f"embedding_Bristol_2024_new/{base_name}_note_embeddings.json"
HEADER_LOOKUP = {
    "Balance Sheet": [
        "Statement of financial position",
        "Notes to the regulatory accounts",
        "Regulatory Financial Reporting – SBB"
    ],
    "Consolidated Statement of Financial Position": [
        "Statement of financial position",
        "Notes to the regulatory accounts",
        "Regulatory Financial Reporting – SBB"
    ],
    "Consolidated Balance Sheet": [
       "Statement of financial position",
       "Notes to the regulatory accounts",
       "Regulatory Financial Reporting – SBB"
    ],
    "Group and Parent Company Balance Sheet": [
       "Statement of financial position",
       "Notes to the regulatory accounts",
       "Regulatory Financial Reporting – SBB"
    ],
    "Consolidated and Company Balance sheet": [
       "Statement of financial position",
       "Notes to the regulatory accounts",
       "Regulatory Financial Reporting – SBB"
    ],
    "Company Balance Sheet": [
       "Statement of financial position",
       "Notes to the regulatory accounts",
       "Regulatory Financial Reporting – SBB"
    ],
    "Consolidated Balance Sheet": [
       "Statement of financial position",
       "Notes to the regulatory accounts",
       "Regulatory Financial Reporting – SBB"
    ]


}
